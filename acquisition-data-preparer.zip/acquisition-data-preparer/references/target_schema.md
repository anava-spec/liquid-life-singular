# Target Schema — Contacts + Deals Import CSVs

The skill produces **two** CSVs, imported in this order:

1. **Contacts CSV** first — one row per *unique* owner (person or entity+
   person), deduplicated across units. If the same owner appears on three
   units, they appear once here, not three times.
2. **Deals CSV** second — one row per unit/acquisition deal. Each row's
   staging columns feed a CRM-native automation (the "Link Resolver") that
   creates the actual linked-record references after import — see
   "How linking actually works" below.

Import order matters: the Link Resolver's Contact match only works if the
matching Contact rows already exist.

**Destination:** production CRM base, `appxnfV7KNmlqWDJs`.
- Contacts table: `tbl96PCoZ4sg5roA7`
- Deals table: `tblxEH4crrCacWt8S`

There is no sandbox step for this import — rows go straight to production.

## ⚠️ CSV import cannot write to linked-record fields — confirmed, resolved

Airtable's CSV import does not accept text for `multipleRecordLinks` fields —
pasting a name into a linked-field column does not auto-match or auto-create
the link. This affects `main_category`, `sub_category`, `owner_name`,
`unit`, and `parcel` on Deals — all five are `multipleRecordLinks`.

**This is why every Deals CSV column that feeds a linked field uses a
`*_acquisition_import` plain-text staging name instead of the real field
name.** These staging fields exist natively on `deals` in the CRM
(production, no sandbox) and are consumed entirely by automations after
import — never touched by CSV import directly. Column names in this CSV
must match the staging field names **exactly** — Airtable matches import
columns to fields by name.

## How linking actually works (built, in production, as of 2026-07)

A chain of automations resolves every staging field into its real link,
without any of them ever writing across a base boundary in the direction
that turned out to be blocked (see "Hard-won lesson" below). None of this
is the skill's job to build — the skill only needs to populate the staging
columns correctly. Documented here so it's clear *why* the columns are
shaped the way they are.

1. **Link Resolver** (CRM, native) — on import, searches for exact matches
   against `main_category`, `sub_category`, `unit`, `parcel`, `owner_name`,
   and `previous_deal` (see "Sequencing" below) and links whatever already
   exists. Never creates anything.
2. **Sub Category / Complex creation** (Unit Management, native) — for
   values that don't match anything yet, creates the missing
   `source_catalog` / `complex_catalog` record natively there.
3. **Sub Category / Parcel / Unit writeback** (CRM, Mailing List — each
   native to wherever the record needs to land) — reacts to the new record
   arriving via normal Airtable sync propagation (always reliable in the
   create/read direction) and links it back to the waiting Deal(s), fully
   within its own base.

**Hard-won lesson, worth knowing if this ever needs touching again:**
editing a *synced* field's value from the base that receives the sync
(e.g. Unit Management editing a field that lives on Mailing List's Parcel,
even with "Allow edits from other bases" and "All editable fields"
explicitly configured) reliably fails with `Edits to synced field ... are
not allowed from this origin` — confirmed across a checkbox and a single
select attempt. The fix that ended up working was **always writing from
the side that owns the field**, and letting the *other* side react to the
read-only, always-reliable arrival of a new synced record instead. Every
writeback in this system follows that rule now.

## Sequencing — required to avoid duplicate-record races

`sub_category` and `complex` creation both risk a real race: two deals in
the same batch discovering the same brand-new category/complex at the same
moment could each try to create it, producing duplicates. To prevent this,
deals are processed in a strict chain, one at a time, using two staging
columns:

- `sequence_order` — this deal's position in the batch (`1`, `2`, `3`, ...).
- `previous_deal_acquisition_import` — the `deal_name` of the deal one
  position earlier in the same batch. Blank for `sequence_order = 1`.

The Link Resolver links `previous_deal_acquisition_import` to the real
`previous_deal` record, and a formula/lookup chain (native to CRM, not the
skill's concern) uses that link to release each deal into the
categorization automations only once the previous one has finished. **Every
Deals CSV must include both columns, correctly chained, or every deal after
the first in the batch will never process.**

Assign these in whatever order you build the Deals CSV rows — order doesn't
need to match anything meaningful in the source data, it just needs to be
internally consistent (row *N*'s `previous_deal_acquisition_import` must
equal row *N-1*'s `deal_name`, and no two rows may share a `sequence_order`).
`scripts/matching.py` handles this — see `assign_sequence_chain()`.

## Column-to-field mapping — Contacts CSV

All fields below already exist on `contacts` — no new fields needed for
this table.

| CSV column | Airtable field | Field ID | Type | Notes |
|---|---|---|---|---|
| `llc_name` | llc_name | `fldKNxbk0aD0q56fX` | singleLineText | Blank if owner is an individual, no entity |
| `first_name` | first_name | `fldGx49UAsx1YoOrN` | singleLineText | |
| `last_name` | last_name | `fldIKA8BSFpHNsOBN` | singleLineText | |
| `owner_role` | owner_role | `fldbwJfEtlLoMwmxb` | singleSelect | `Primary Owner` / `Secondary Owner` — first name listed on the source row is Primary, unless a free-text note names someone else (see SKILL.md Step 4) |
| `contact_type` | contact_type | `fld0sCAQfFcgGhWJO` | singleSelect | Use `Current Liquid Life Owner` for acquisition-sourced contacts |
| `email` | email | `fldReeNZZfSR6zZqD` | email | Check every sheet received, not just the obvious "owner info" one. Leave blank only if truly absent everywhere, never a placeholder |
| `phone` | phone | `fldQcbrnWHZWiRzXi` | phoneNumber | Same rule as email |
| `is_acquisition` | is_acquisition | `fldctAqOSay0ZZF3Y` | singleSelect | Always `"Yes, contact comes from an acquisition"` (exact option text — the other option is `"No, contact doesn't come from an acquisition"`) for every row this skill produces. Mirrors `deals.is_acquisition` but as a singleSelect, not a checkbox |

## Column-to-field mapping — Deals CSV

| CSV column | Airtable field it feeds | Field ID | Type | Notes |
|---|---|---|---|---|
| `deal_name` | deal_name | `fldvCt5T0zQ1gYD2j` | singleLineText | e.g. `"Acquisition - BF101"` — `"Acquisition - "` + the unit code |
| `main_category_acquisition_import` | main_category_acquisition_import (staging) → main_category | `fldNYaRiOpwS1bCzb` | singleLineText | Always `"Acquisition"` |
| `sub_category_acquisition_import` | sub_category_acquisition_import (staging) → sub_category | `fldXcU8OPwTeKR5vS` | singleLineText | Name of the acquired company, e.g. `"Current Tides"` |
| `complex_acquisition_import` | complex_acquisition_import (staging) → Parcel.complex / Unit.complex | `fldKcwPELTLcHvNRb` | singleLineText | **Known gap (2026-07):** the skill doesn't parse this from source sheets yet — leave blank unless/until complex extraction is built. Never invent a value. If the source data has an obvious complex/property-group name, flag it to the user rather than guessing at the exact `complex_catalog` naming convention (e.g. "The Colonnades" vs "Colonnades" — see known_source_formats.md) |
| `unit_acquisition_import` | unit_acquisition_import (staging) → unit | `fldoRJkvj7CctUqIz` | singleLineText | The unit code (e.g. `"BF101"`). Also becomes `Parcel.parcel_id` and `Parcel.unit_code` downstream — confirmed the unit code is the correct value for both, not the address |
| `parcel_acquisition_import` | parcel_acquisition_import (staging) → parcel | `fldsdCxahYs5OTAkg` | singleLineText | The full property **address** (e.g. `"1125 W Beach Blvd #101, Gulf Shores, AL 36542, USA"`) — used only for Parcel creation/address-parsing downstream, NOT for matching (matching uses unit code) |
| `is_acquisition` | is_acquisition | `fld9kp5e5Y2v3Ej2f` | checkbox | Always `TRUE` for every row this skill produces |
| `amount` | amount | `fld5WkGW0CrOvOZPP` | currency | From the income-projection sheet, final projected value for the unit |
| `stage` | stage | `fld52XVQt9uvrcEwp` | singleSelect | Default `Discovery/Qualification` |
| `signed_rental_date` | signed_rental_date | `fldHrrGYaFmNsnmC5` | date | Plain date field, not a link — imports directly, no staging column needed. Left blank by default unless the user has explicitly given a date for this acquisition (ask — don't assume blank is always correct; confirmed per-acquisition, not a fixed rule) |
| `owner_contact_acquisition_import` | owner_contact_acquisition_import (staging) → owner_name | `fldoj6J68a9n69gmp` | singleLineText | One or more `first_name last_name` strings (never `llc_name`), comma-separated for multi-owner deals |
| `sequence_order` | sequence_order | `fldmVskTfU0UsK3wc` | number | This deal's 1-indexed position in the batch — see "Sequencing" above |
| `previous_deal_acquisition_import` | previous_deal_acquisition_import (staging) → previous_deal | `fldoojNf7jk1V5jb7` | singleLineText | The `deal_name` of the previous deal in the batch — blank only for `sequence_order = 1` |

**Removed from this export (2026-07):** `acquisition_missing_parcel_flag`,
`acquisition_missing_unit_flag`, and `acquisition_data_completeness` are no
longer part of the Deals CSV. The downstream automations create missing
Parcel/Unit/Complex records automatically (search-or-create, native to
whichever base owns each table) regardless of whether a flag says they're
missing — the flags were never actually read by anything. Don't add them
back without checking with the user first. The skill can still track
completeness *internally* (for its own manual-review workflow in SKILL.md
Step 5/7) — it just no longer exports that status to Airtable.

## Row-level rules

**Contacts CSV:**
- One row per *unique* owner across the whole acquisition — dedupe by
  (`first_name`, `last_name`). If the same person/entity owns multiple
  units, they still get exactly one Contact row.
- If duplicate rows disagree on `email`/`phone` (one blank, one populated),
  keep the populated one — same authority rule as Step 3 in `SKILL.md`.

**Deals CSV:**
- One row per unit/deal, regardless of how many owners it has.
- `owner_contact_acquisition_import` must list every owner for that unit,
  comma-separated, using the exact `first_name last_name` text that will
  appear on the matching Contact after import.
- `sequence_order` and `previous_deal_acquisition_import` must form a
  single, unbroken chain across every row in the batch — see "Sequencing"
  above. This is not optional; without it the categorization automations
  never advance past the first deal.

**Both CSVs:**
- If a row is `Needs Manual Review` (skill's internal tracking — no longer
  exported as a column), still emit it so the human reviewer has something
  concrete to correct rather than a gap they have to reconstruct from
  scratch.
- Never write a value into `email`, `phone`, or `complex_acquisition_import`
  to satisfy a "complete-looking" row. Confirm every sheet was checked
  (Step 0/3 in `SKILL.md`) before leaving any of them blank.

## Contact matching mechanics (for the Link Resolver, not this skill directly)

`contacts.contact_name` (the primary field, formula) is:

```
TRIM(first_name & " " & last_name)
```

**It does not include `llc_name`.** Build every match string this way:
`f"{first_name} {last_name}".strip()` — matches the `TRIM()` on the Airtable
side, so a blank `last_name` (e.g. `first_name = "Dr. Vaughn"`,
`last_name = ""`) no longer leaves a trailing space mismatch between what
this skill emits and what `contact_name` actually resolves to after import.
For deals with multiple owners, join them with `, ` in
`owner_contact_acquisition_import`.

**Formerly a known limitation, now fixed (2026-07):** rows where
`first_name` holds the full raw string and `last_name` is blank (e.g.
"Dr. Vaughn") used to produce a `contact_name` with a trailing space,
since the formula was a plain concatenation. `contact_name` is now wrapped
in `TRIM()`, so this no longer causes a mismatch — this skill's own
match-string construction (`.strip()`) already matched what `TRIM()`
produces, so no change was needed on the skill's side, only on the
Airtable formula.

## Downstream dependency notes (not this skill's job, but affects it)

- **Campaign / `source_campaign`** doesn't apply when
  `main_category = Acquisition` — confirmed by the user. This skill doesn't
  populate a campaign value and shouldn't.
- **`Former PM Company`** on the created Parcel is set downstream to the
  resolved `sub_category` value (e.g. `"Current Tides"`) — the skill
  doesn't need to do anything for this, just make sure
  `sub_category_acquisition_import` is populated.
- **Address parsing** for `Parcel Address`/`City`/`State`/`Zip` happens
  downstream (Parcel-creation automation), from `parcel_acquisition_import`.
  If that automation can't parse an address shape it doesn't recognize, it
  leaves those fields blank and logs a warning rather than failing — this
  skill doesn't need to pre-validate address format, just pass through
  whatever the source data has.
