# Known Source Formats (Reference Examples Only)

These are anonymized examples of the kinds of sheets an acquired company has
handed over in the past. They exist to give you a starting intuition for
what "normal" looks like — **not** a fixed template. Sometimes there's one
sheet, sometimes three or more, and the column names and structure vary by
acquisition. Detect what each sheet actually is from its headers and content
every time; don't assume any acquisition will match these exactly.

All names, addresses, and identifiers below are fictional.

## Example 1 — Property / Unit Crosswalk

Bridges the acquired company's naming for a property with the client's own
internal nickname for it.

| Acquired Co. Nickname | Client Nickname | City | Zone | Type | BR | Owner |
|---|---|---|---|---|---|---|
| Palm Court 4B | PC4B | Sunview, FL | East | Condominium | 2 | Ortiz Family LLC (Marco Ortiz) |
| Beachwalk 12 | BW12 | Sunview, FL | West | Condominium | 3 | Dana Whitfield |

Notice the two nickname columns don't share a naming convention — one is
descriptive, the other is a compressed code. When two sheets need to be
joined and neither shares an obvious key, look for a sheet like this one
that bridges them.

## Example 2 — Owner Info

One row per property, giving the legal owner and address, usually **without**
contact details (email/phone come later, once a contract is signed).

| Owner Name | Property Name | Property Address | Owner Agreement | Owner W-9 |
|---|---|---|---|---|
| Ortiz Family LLC (Marco Ortiz) | Palm Court 4B | 12 Ocean Dr, Sunview, FL | TRUE | TRUE |
| Dana Whitfield | Beachwalk 12 | 45 Shore Ave, Sunview, FL | TRUE | FALSE |

Owner names frequently mix an entity name with one or two individuals in
parentheses, or list two individuals joined by "and"/"&". Both need to be
split out — see the owner-name parsing rules in `SKILL.md`.

## Example 3 — Rental Income Projections

One row per unit, usually with a clean, consistent unit code — this sheet's
unit identifier is often the most reliable join key across all the sheets,
because it tends to match a client-side nickname or code more consistently
than the acquired company's own naming does.

| Unit | Complex | Bedrooms | Final Projection |
|---|---|---|---|
| PC4B | Palm Court | 2 | $38,400 |
| BW12 | Beachwalk | 3 | $41,900 |

## Example 4 — Operational Tracker (contact info can hide here)

Acquired companies sometimes also hand over an operational or onboarding
tracker — not built for the CRM at all, just for internal task tracking —
that happens to contain the most complete owner contact info of any sheet
provided. Don't assume the sheet literally named "Owner Info" is the only
place to look for owner email/phone.

| Owner | Units | Email | Phone | Notes |
|---|---|---|---|---|
| Ortiz Family LLC | Palm Court 4B | ortiz@example.com | +1 555-0100 | Marco is primary contact; his sister Elena handles paperwork if unreachable |

That `Notes` column is exactly the kind of free-text field that can
contradict a structured default. If a note says a different person should
be the primary contact than whichever name happens to be listed first, that
is a real conflict to raise with the user — not something to resolve
silently in either direction.

## What tends to be true across acquisitions (not guaranteed)

- There is rarely a shared unique ID across every sheet — expect to need a
  crosswalk or a fuzzy match, not a clean join key, at least for one pair of
  sheets.
- Owner contact info is sometimes present, sometimes not, and when it is
  present it isn't always in the sheet you'd expect — check everything
  before concluding it's missing.
- The number of units and the number of rows in each sheet can differ by one
  or two — don't assume row counts will match perfectly; reconcile by name
  before concluding a unit is missing from a sheet.
- Compound owner names (entity + individual, two individuals, "Last, First"
  order, etc.) are common enough that the parsing logic should be a
  first-class step, not an edge case handled only when it comes up.
- Free-text notes fields can carry information that overrides a structured
  default (e.g. who the real point of contact is) — always worth scanning,
  never worth ignoring.
