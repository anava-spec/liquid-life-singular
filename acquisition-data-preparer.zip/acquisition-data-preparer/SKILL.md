---
name: acquisition-data-preparer
description: Prepares raw acquisition data (contacts, owners, units, parcels, projected income — in whatever sheets the acquired company happened to hand over) for import into the Liquid Life CRM. Use this whenever the user mentions an acquisition, a portfolio of acquired units, onboarding units from a company Liquid Life bought or is buying, or uploads spreadsheets/workbooks describing acquired properties and owners. Also trigger if the user asks to "prepare an import," "get this ready for Airtable," or similar, in the context of acquired units or properties — even if they don't use the word "acquisition" explicitly. This skill never connects to Airtable itself; it only analyzes data and produces a CSV for a human to import.
---

# Acquisition Data Preparer

## Why this exists

Liquid Life periodically acquires portfolios of vacation rental units from
other management companies. Each acquisition shows up as a pile of
spreadsheets from the acquired company — never the same shape twice, often
inconsistent even within itself, spread across however many sheets the
acquired company happened to keep, and never containing everything the CRM
needs in one obvious place. Before this skill, someone had to manually
reconcile all of that by hand for every single acquisition. This skill does
the reconciliation work and hands back one clean CSV a human can actually
import — and it's built to keep working on acquisitions that look nothing
like the ones it was first built against, without Liquid Life or Singular
needing to maintain it by hand each time.

**The one hard rule that overrides everything else in this file:** this
skill never touches Airtable. No API calls, no credentials, no MCP
connectors, no "let me just save this for you." It analyzes data and
produces a CSV. A human always does the import. If you find yourself about
to call an Airtable tool while running this skill, stop — that's not this
skill's job, even if it would be faster.

## What you're building toward

The final deliverable is two CSVs — Contacts, then Deals — matching the
schema in `references/target_schema.md`. Read that file now if you haven't
— it has the exact columns, field IDs, per-column rules, and the linking
mechanism between the two files. Do not improvise column names.

`assets/manual_review_template.html` is a reusable fallback UI for Step 5
— see that step for when and how to use it.

## Step 0 — Inventory everything before classifying anything

Don't process sheet-by-sheet in isolation. First, take stock of *all* the
sheets you received and build a mental (or literal, if useful) coverage map:
for each piece of data the target schema needs — owner name, owner email,
owner phone, unit identifier, parcel identifier, deal amount, signed rental
date, address — which sheet(s) actually contain it?

This matters because acquisitions vary in how many sheets they come in and
what each one covers. Sometimes owner contact info is sitting in a sheet you
wouldn't expect to hold it (an owner-tracking or master sheet, rather than
the sheet that looks like "owner info" at a glance). Don't decide a field is
missing until you've checked every sheet you were given, not just the one
whose name or first impression suggested it was the right one.

## Step 1 — Receive the raw data

Accept whatever the user uploads or pastes — one file or several, one sheet
or many tabs inside a workbook. Don't assume a fixed number or shape. Read
`references/known_source_formats.md` for a feel of what these sheets
typically look like, but treat it as intuition-building, not a template to
match against. Every acquisition is allowed to look different.

## Step 2 — Classify what each sheet actually is

For each sheet, look at the headers and sample rows and figure out what it
represents: a property/unit crosswalk, owner info, income projections, a
combined "everything in one row" source sheet, an operational tracker with
incidental owner contact info, or something else entirely. Some workbooks
will hand you five relevant sheets, others will hand you one. If a sheet
doesn't fit any pattern you recognize, don't force it — work out what it
actually contains and how it relates to the others, or ask the user (with
options, per Step 5).

If sheets don't share an obvious join key, look for a crosswalk-shaped sheet
that bridges them — that's the most common pattern, but not the only one.

## Step 3 — Resolve by authority, not by default

For every field in the target schema, once you know which sheet(s) cover it
(from Step 0), apply this rule: **use whichever sheet actually has the
value.** If one sheet leaves a field blank and another sheet — anywhere in
what you were given — has it populated, use the populated one. Never assume
a field is "just not available for this acquisition" without having checked
everywhere it could plausibly live.

Only leave a field blank on the final CSV when *no* sheet you received
contains it. That's a real gap, not a default.

Use `scripts/matching.py` for the parts of this that should be deterministic
and reproducible rather than re-derived by reasoning about strings each time:

- **Exact joins** (a code that's genuinely identical across two sheets) →
  `exact_join()`.
- **Fuzzy joins** (two differently-abbreviated names for the same property)
  → `fuzzy_join_with_owner_tiebreaker()`. This already implements the rule
  that a fuzzy match must be confirmed by the owner name when the key match
  alone isn't strong enough, and routes anything still ambiguous to manual
  review instead of guessing.
- **Owner-name parsing** ("Entity LLC (First Last)", "First and First Last",
  "Last, First and First", etc.) → `parse_owner_name()`. Real data will not
  all match one shape — extend the parser (see Step 8) rather than
  special-casing exceptions in conversation.
- **Field coverage inventory** → `inventory_coverage()` can help you check,
  programmatically, which of several loaded sheets has non-empty values for
  a given field across rows, instead of eyeballing it.
- **Final CSV rows** → `build_rows_for_unit()` and `write_csv()`.

## Step 4 — Watch for free-text signals that override structured defaults

Structured columns give you defaults (e.g. "the first name listed is the
primary owner"). Free-text fields — notes, comments, call logs — sometimes
contradict those defaults with something more authoritative. For example, a
notes column might say a specific person, not the first name listed, should
be the primary contact.

When you find this kind of contradiction, **do not silently apply the
structured default and do not silently override it either.** Stop and raise
it to the user as a specific, concrete question (per Step 5) — this is
exactly the kind of judgment call that should involve a human, because only
Liquid Life knows which source is actually right.

## Step 5 — Flag gaps and conflicts back to the user

Two kinds of things come up, and they get handled differently:

**Resolvable through a quick decision** — an ambiguous fuzzy match, a
free-text contradiction (Step 4), an owner-name string the parser can't
confidently split. Present these as multiple-choice questions whenever you
can construct real options from the data you have (e.g. "Which of these
three addresses is Unit X? A / B / C", or "The Owner Tracker notes say Amie
Bond should be primary contact, not Ronald or Kay Bryant — use Amie Bond as
primary, or keep the first-listed name?"). Avoid open-ended questions —
they're slower and produce less consistent answers. Only fall back to an
open question when there's genuinely no way to enumerate the plausible
options.

**Missing structurally** — a data point isn't in anything you were given,
after checking every sheet (Step 0/3). Ask the user to supply that
document or value rather than guessing or leaving it blank silently.

**When there are many rows to review at once** (a batch of unresolved
owner-name splits, several flagged conflicts), don't ask one multiple-choice
question per row, and don't hand the user the entire batch to fix by hand
either — that works at 40 rows and breaks down at 400 or 4,000. Instead:

1. If a group of rows share the *same kind* of gap (e.g., all failed
   `parse_owner_name()` for the same structural reason), treat it as a
   pattern to learn, not a pile of individual corrections. Pull a small,
   representative sample — not just the first few, but a spread that covers
   the variety of shapes in the raw strings (different lengths, different
   punctuation, one with "and", one without, etc.) — rather than the whole
   group. Say how many are flagged and how many you're sampling, and why:
   *"The 'Last, First' pattern isn't recognized — there are 40 rows like
   this. Want me to pull a representative sample of ~8 for you to correct,
   so I can work out the general rule and apply it to the rest?"*
2. Present that sample (or the full batch, for gaps too small or too varied
   to sample meaningfully) for correction. Try the Visualizer
   (`visualize:show_widget`) first, for an interactive, editable table. If
   the Visualizer tool fails, retry once more; if it fails a second time,
   fall back to `assets/manual_review_template.html` — fill in `__TITLE__`
   and substitute the flagged rows (as JSON, matching the shape `{unit,
   ct_nickname, llc_name, first_name, last_name, owner_role, email, phone}`)
   into `__DATA__`, write the result to the outputs directory, and present
   it as a file. This template lets the user edit rows inline, add a row
   when one contact is actually two people, remove a row, and copy the
   corrected JSON to their clipboard. It groups rows by the kind of gap
   (e.g. "unrecognized pattern" vs. "contact overridden per a note"),
   shows smaller groups first, floats any `suggested`-sample rows to the
   top of their group, lets each group collapse, and tracks a per-group
   ready/pending state (automatic for sampled groups once the suggested
   rows are filled in; a manual toggle for groups without a sample). Set
   each row's `group` field when building the JSON so this all works.
3. Once the user gives you back the corrected data (automatically via the
   Visualizer, or pasted back into the chat from the HTML fallback), use it.
   If you sampled: work out the general rule the corrections imply — not a
   lookup table of the specific names, but the actual pattern (e.g., "when
   the string is `Lastname, Firstname`, split on the comma and swap the
   order") — and apply that rule to the rest of the flagged group yourself.
   If you presented the full batch: just use the corrections directly.
4. Report back plainly what happened: how many rows an inferred rule
   resolved automatically, and how many still don't fit it and remain
   flagged for individual review. Don't silently claim full resolution if
   some rows still don't match. Don't proceed to Step 7 on the original
   flagged data if the user was in the middle of correcting it.
5. A pattern learned this way is exactly what `scripts/matching.py` should
   learn permanently — flow it into the Step 8 evolution proposal so the
   next acquisition doesn't need this sample-and-correct round at all.

The goal is that reviewing a data-quality pattern costs the user a fixed,
small amount of effort regardless of whether it shows up 40 times or 4,000.

Must-have vs. nice-to-have, so gaps don't block progress unnecessarily:

- **Must-have** (blocks the row if missing everywhere, gets flagged for
  manual review): owner name (or enough to identify at least one
  individual), a unit identifier.
- **Nice-to-have** (row proceeds without it, left blank — never filled
  with a placeholder — only after Step 3 confirms it's truly absent
  everywhere): owner email, owner phone. `signed_rental_date` is a special
  case — ask the user whether this acquisition has one confirmed date to
  apply across every deal (common — Liquid Life often applies a single
  signed date in bulk); don't assume it's always blank or always present.

## Step 6 — Missing Parcels/Units/Complex are not this skill's problem anymore

Earlier versions of this skill flagged missing Parcels/Units with dedicated
columns so a human (or a not-yet-built mechanism) would know to create them.
**That mechanism has since been built, and it's fully automatic:**
downstream CRM/Unit Management/Mailing List automations search for an
existing Parcel/Unit/Complex by the identifiers this skill provides, and
create whichever ones don't exist yet — natively, without any flag telling
them to.

This means: just populate `unit_acquisition_import`,
`parcel_acquisition_import`, and (if known) `complex_acquisition_import`
with whatever the source data actually says. Don't try to determine whether
a Parcel/Unit already exists — you don't have visibility into Airtable from
here, and the downstream automations will resolve it correctly either way
(link if it exists, create if it doesn't). Still emit every row regardless.

The one exception: `complex_acquisition_import` has no automated extraction
built yet (see `target_schema.md`) — if source data has an obvious complex
name, ask the user how to handle it rather than guessing at
`complex_catalog`'s exact naming convention.

## Step 7 — Verify, then build and deliver two CSVs, in order

**Don't deliver the CSVs yet if any row is still `Needs Manual Review`.**
Build them (so you can verify against real output), but hold off on
presenting them to the user. Instead, report status plainly in your normal
response — how many rows are Complete, how many are still flagged and
why — and ask, as an ordinary sentence in that same response (not through
an interactive question tool), whether they want the CSVs now with the
remaining rows flagged as-is, or want to resolve those first. Only present
the files once the user answers, either by giving you corrected data or by
telling you to proceed anyway.

Before writing anything, verify that every correction, override, or
resolution decided earlier in this run actually landed in the data you're
about to output — don't rely on remembering that you applied something.
Call `M.assert_all_keys_consumed()` (or an equivalent check) for any
keyed correction against the real set of unit/contact identifiers in the
data, so a typo'd key fails loudly here instead of silently doing nothing.
This matters because that exact failure mode — a hand-typed identifier
that doesn't match anything, with no error and no visible symptom — is
what caused a real incident during development of this skill. Silence is
not evidence that a correction applied; check it.

After building the CSVs, spot-check the specific decisions made during
this conversation (each override, each resolved conflict) actually appear
in the output — e.g., search the Deals CSV for the name that was supposed
to replace a default, and confirm it's there. Report this verification to
the user as part of delivering the files, not just the row counts — e.g.,
"confirmed: Lynne Paugh is linked to ST101, Rachel Underwood to CA1C." A
silent "it's done" is not the same as a verified one.

This mechanism produces **two** CSVs, not one — read
`references/target_schema.md` in full before building either, especially
the "Linking Deals to Contacts" section.

1. **Contacts CSV** — one row per *unique* owner (person or entity+person),
   deduplicated across the whole acquisition. If the same owner appears on
   three units, they appear once here.
2. **Deals CSV** — one row per unit. Each row's `owner_contact_acquisition_import`
   column lists the `first_name last_name` of every owner on that deal
   (never `llc_name` — see target_schema.md for why), comma-separated for
   multi-owner deals. `is_acquisition` is always `TRUE`.

**Before writing the Deals CSV, call `assign_sequence_chain()`** on the
full list of built rows — this fills in `sequence_order` and
`previous_deal_acquisition_import` for every row, forming the unbroken
chain the categorization automations require (see target_schema.md
"Sequencing"). Skipping this step means every deal after the first in the
batch will never process downstream — it's not optional, and it's easy to
forget since nothing about building the rows themselves fails without it.

Tell the user plainly: **import the Contacts CSV first, then the Deals
CSV** — the Deals CSV's linked-record match against Contacts only works if
those Contact rows already exist. No intermediate review tool, no
automation reaches into Airtable on this skill's behalf; a human does both
imports directly.

## Step 8 — Propose evolution, but let a human decide

If you hit a sheet shape, naming convention, or owner-string pattern that
`scripts/matching.py` or `references/known_source_formats.md` doesn't handle
well, that's valuable — the next acquisition will likely need it too. But
don't edit those files on your own initiative mid-task.

Instead, at the point you'd want to extend them, note what you'd change and
why, and at the end of the run present it to the user as a specific,
concrete proposal: "I had to handle [pattern] by hand this time. I could add
support for it to the skill so future acquisitions with this pattern are
handled automatically. Want me to update the skill with this, or leave it
as-is for now?" Only write the change if they say yes. If they decline,
proceed without it — don't re-ask in the same session.

This keeps the skill improving over time without requiring Liquid Life or
Singular to maintain it by hand, while keeping a human in control of what
actually becomes permanent.
