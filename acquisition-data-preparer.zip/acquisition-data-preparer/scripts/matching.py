"""
matching.py — deterministic helpers for the acquisition-data-preparer skill.

This script does the parts of the pipeline that should give the same answer
every time it's run, so they aren't left to per-conversation judgment:

  1. Exact-match join between two sheets on a nickname/code column.
  2. Fuzzy-match join between two sheets on a nickname/name column, using a
     third "owner name" column as a tiebreaker when the fuzzy match alone
     is ambiguous.
  3. Splitting a compound owner-name string ("Entity LLC (First Last)",
     "First Last and First Last", etc.) into an llc_name plus one or two
     individual owners, in listed order (first listed = Primary Owner).
  4. Assembling the final one-row-per-owner CSV described in
     references/target_schema.md, including the sequence_order /
     previous_deal_acquisition_import chain required by the categorization
     automations (assign_sequence_chain()).

Nothing in this file reads from or writes to Airtable. Its only output is a
CSV file on disk — importing that CSV into Airtable is always a human step.

Usage is intentionally not fixed to Current Tides' three-sheet shape: call
the pieces you need for whatever sheets a given acquisition actually
provides. See SKILL.md for how the skill decides which function applies to
which uploaded sheet.
"""

from __future__ import annotations

import csv
import difflib
import re
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# 0. Field coverage inventory (Step 0 in SKILL.md)
# ---------------------------------------------------------------------------

def inventory_coverage(
    sheets: dict[str, list[dict]],
    field_candidates: dict[str, list[str]],
) -> dict[str, dict[str, int]]:
    """Report, per target field, which sheets have non-empty values for it.

    `sheets` maps a sheet name to its rows (list of row-dicts).
    `field_candidates` maps a logical field name (e.g. "owner_email") to a
    list of plausible column-name spellings that might hold it in any given
    sheet (e.g. ["Email", "Owner Email", "email"]).

    Returns a dict like:
        {"owner_email": {"Owner Tracker": 58, "Owner Info from CT": 0}}
    i.e. how many non-empty values each sheet contributes for that field,
    using whichever candidate column name is actually present in that sheet.

    This exists so "is this field really missing?" is answered by counting,
    not by eyeballing one sheet and assuming the rest don't have it either —
    that's the mistake Step 0 in SKILL.md exists to prevent.
    """
    report: dict[str, dict[str, int]] = {}

    for field_name, candidates in field_candidates.items():
        report[field_name] = {}
        for sheet_name, rows in sheets.items():
            if not rows:
                report[field_name][sheet_name] = 0
                continue
            # Find which candidate column name (if any) exists in this sheet.
            available_cols = set(rows[0].keys())
            matching_col = next((c for c in candidates if c in available_cols), None)
            if matching_col is None:
                continue  # this sheet doesn't even have a column for this field
            non_empty = sum(1 for r in rows if (r.get(matching_col) or "").strip())
            report[field_name][sheet_name] = non_empty

    return report


# ---------------------------------------------------------------------------
# 0b. Representative sampling for the sample-then-generalize workflow
# ---------------------------------------------------------------------------

def sample_for_pattern_review(items: list, n: int = 8) -> list:
    """Pick a spread of `n` items likely to cover a group's variety, rather
    than just the first few or a pure random pick.

    `items` is any list where each item can be converted to a string that
    reflects its "shape" (e.g. the raw owner-name string). Sampling by
    string length is a cheap proxy for structural variety — short, long,
    and evenly spaced items in between are more likely to represent
    different sub-patterns than N items pulled from the same neighborhood.

    This exists so the sample handed to a human for correction (SKILL.md
    Step 5) has a real chance of covering the range of shapes in the full
    group, not just whichever rows happened to load first.
    """
    if len(items) <= n:
        return list(items)

    indexed = sorted(range(len(items)), key=lambda i: len(str(items[i])))
    picks_idx = sorted(set(
        indexed[round(i * (len(indexed) - 1) / (n - 1))] for i in range(n)
    ))
    picks_idx = list(picks_idx)
    remaining = [i for i in range(len(items)) if i not in picks_idx]
    while len(picks_idx) < n and remaining:
        picks_idx.append(remaining.pop(len(remaining) // 2))
    picks_idx = sorted(picks_idx[:n])

    return [items[i] for i in picks_idx]


def assert_all_keys_consumed(applied_keys, valid_keys, context: str = "") -> None:
    """Raise loudly if any key meant to apply to real data never matched.

    This exists because dict-lookup-based corrections (e.g. "override unit
    X's owner") fail *silently* when the key doesn't match anything — no
    exception, no warning, the correction just quietly never applies. That
    class of bug is exactly what caused a real incident: two contact
    overrides were typed with the wrong unit codes and never applied,
    and nothing surfaced it until a human happened to ask about the count.

    Call this immediately after applying any keyed correction, override, or
    join, passing the keys you intended to consume and the full set of
    valid keys they should have matched against. Any key that isn't in
    `valid_keys` gets raised as an error before it can silently do nothing.
    """
    applied_keys = set(applied_keys)
    valid_keys = set(valid_keys)
    unmatched = applied_keys - valid_keys
    if unmatched:
        where = f" ({context})" if context else ""
        raise ValueError(
            f"These keys{where} don't match any real record and would have "
            f"silently done nothing: {sorted(unmatched)}. Check for typos "
            f"against the actual identifiers in the data before proceeding."
        )


def normalize_key(value: str) -> str:
    """Loose normalization for exact-match keys: case/whitespace only.

    Exact join should still mean exact — this only forgives the kind of
    incidental formatting differences (double spaces, stray casing) that
    aren't a real naming discrepancy.
    """
    return re.sub(r"\s+", " ", (value or "").strip()).lower()


def exact_join(rows_a: list[dict], key_a: str, rows_b: list[dict], key_b: str):
    """Join two lists of row-dicts on an exact (normalized) key match.

    Returns (matched, unmatched_a, unmatched_b) where `matched` is a list of
    (row_a, row_b) tuples.
    """
    index_b = {}
    for row in rows_b:
        index_b.setdefault(normalize_key(row.get(key_b, "")), []).append(row)

    matched, unmatched_a = [], []
    used_b_ids = set()
    for row in rows_a:
        k = normalize_key(row.get(key_a, ""))
        candidates = index_b.get(k, [])
        if len(candidates) == 1:
            matched.append((row, candidates[0]))
            used_b_ids.add(id(candidates[0]))
        else:
            unmatched_a.append(row)

    unmatched_b = [r for r in rows_b if id(r) not in used_b_ids]
    return matched, unmatched_a, unmatched_b


# ---------------------------------------------------------------------------
# 2. Fuzzy-match join with owner-name tiebreaker
# ---------------------------------------------------------------------------

@dataclass
class FuzzyMatchResult:
    matched: list[tuple[dict, dict]] = field(default_factory=list)
    needs_manual_review: list[dict] = field(default_factory=list)


def _similarity(a: str, b: str) -> float:
    return difflib.SequenceMatcher(a=normalize_key(a), b=normalize_key(b)).ratio()


def fuzzy_join_with_owner_tiebreaker(
    rows_a: list[dict],
    key_a: str,
    owner_a: str,
    rows_b: list[dict],
    key_b: str,
    owner_b: str,
    name_threshold: float = 0.55,
    accept_threshold: float = 0.85,
) -> FuzzyMatchResult:
    """Join two row lists on a fuzzy string match, breaking ties by owner name.

    For each row in `rows_a`, find candidates in `rows_b` whose key clears
    `name_threshold`. If there's exactly one candidate, or one candidate is
    a clearly better match than the rest AND its owner name also matches
    well, accept it. Otherwise, send the row to manual review rather than
    guessing — this mirrors the rule that unresolved joins must never be
    silently linked.
    """
    result = FuzzyMatchResult()

    for row in rows_a:
        a_key = row.get(key_a, "")
        a_owner = row.get(owner_a, "")

        scored = []
        for cand in rows_b:
            key_score = _similarity(a_key, cand.get(key_b, ""))
            if key_score >= name_threshold:
                owner_score = _similarity(a_owner, cand.get(owner_b, ""))
                scored.append((key_score, owner_score, cand))

        if not scored:
            result.needs_manual_review.append(row)
            continue

        scored.sort(key=lambda t: (t[0], t[1]), reverse=True)
        best_key, best_owner, best_cand = scored[0]

        # Confident if the top key match is strong on its own, OR the owner
        # name confirms it even when the key match alone is middling.
        if best_key >= accept_threshold or (best_key >= name_threshold and best_owner >= accept_threshold):
            result.matched.append((row, best_cand))
        else:
            result.needs_manual_review.append(row)

    return result


# ---------------------------------------------------------------------------
# 3. Owner-name parsing
# ---------------------------------------------------------------------------

@dataclass
class ParsedOwner:
    first_name: str
    last_name: str


@dataclass
class ParsedOwnerName:
    llc_name: Optional[str]
    owners: list[ParsedOwner]
    confident: bool


_ENTITY_PAREN_RE = re.compile(r"^(?P<entity>.+?)\s*\((?P<inside>[^)]+)\)\s*$")
_TWO_PEOPLE_RE = re.compile(
    r"^(?P<first1>[A-Z][a-zA-Z.'-]+)\s+(?:and|&)\s+(?P<first2>[A-Z][a-zA-Z.'-]+)\s+(?P<last>[A-Z][a-zA-Z'-]+)$"
)
_SINGLE_PERSON_RE = re.compile(r"^(?P<first>[A-Z][a-zA-Z.'-]+)\s+(?P<last>[A-Z][a-zA-Z'-]+)$")
# "Lastname, Firstname[s]" — confirmed by human correction on the Current
# Tides acquisition (2026-07): e.g. "Clem, Joey" -> Joey Clem; "Jameson,
# Gary and Leigh" -> Gary Jameson (Primary) + Leigh Jameson (Secondary);
# "McElveen, Dr. Matthew" style titles stay attached to the first-name side.
# Role order (who's Primary) follows the order in the text by default —
# two of the corrected examples reversed that order with no accompanying
# note explaining why, so that reversal is treated as case-specific human
# judgment, not generalized here. If a future correction batch shows a
# consistent reordering signal (e.g. always alphabetical, or always tied to
# who's listed as account holder), come back and adjust this comment and
# the logic together.
_LASTNAME_COMMA_RE = re.compile(
    r"^(?P<last>[A-Z][a-zA-Z'-]*(?:\s+[A-Z][a-zA-Z'-]*)?)\s*,\s*(?P<rest>.+)$"
)


def _split_lastname_comma(raw: str) -> tuple[Optional[str], list[ParsedOwner], bool]:
    """Try the 'Lastname, Firstname[s]' shape. Returns (None, owners, ok)."""
    m = _LASTNAME_COMMA_RE.match(raw.strip())
    if not m:
        return None, [], False

    last = m.group("last").strip()
    rest = m.group("rest").strip()

    parts = re.split(r"\s+(?:and|&)\s+", rest)
    if len(parts) == 2 and all(parts):
        return None, [ParsedOwner(parts[0].strip(), last), ParsedOwner(parts[1].strip(), last)], True

    # Single first name (title prefixes like "Dr. Matthew" stay intact as
    # the first-name value — we don't try to separate the title further).
    if rest:
        return None, [ParsedOwner(rest, last)], True

    return None, [], False


def _split_people(segment: str) -> tuple[list[ParsedOwner], bool]:
    """Parse a segment expected to contain one or two people's names."""
    segment = segment.strip()

    m = _TWO_PEOPLE_RE.match(segment)
    if m:
        return (
            [
                ParsedOwner(m.group("first1"), m.group("last")),
                ParsedOwner(m.group("first2"), m.group("last")),
            ],
            True,
        )

    # "Ronald and Kay Bryant" handled above; try "Ronald Bryant and Kay Smith"
    # (two full names) as a fallback.
    parts = re.split(r"\s+(?:and|&)\s+", segment)
    if len(parts) == 2:
        people = []
        ok = True
        for p in parts:
            m2 = _SINGLE_PERSON_RE.match(p.strip())
            if m2:
                people.append(ParsedOwner(m2.group("first"), m2.group("last")))
            else:
                ok = False
        if ok:
            return people, True

    m3 = _SINGLE_PERSON_RE.match(segment)
    if m3:
        return [ParsedOwner(m3.group("first"), m3.group("last"))], True

    return [], False


def parse_owner_name(raw: str) -> ParsedOwnerName:
    """Split a raw owner-name string into an llc_name plus 1-2 individuals.

    Handles:
      - "Entity LLC (First Last)"           -> llc_name + 1 owner
      - "Entity LLC (First1 and First2 Last)" -> llc_name + 2 owners
      - "First Last"                         -> no llc_name, 1 owner
      - "First1 and First2 Last"             -> no llc_name, 2 owners
      - "Last, First"                        -> no llc_name, 1 owner
      - "Last, First1 and First2"            -> no llc_name, 2 owners

    Anything that doesn't confidently match one of these shapes comes back
    with confident=False — the caller should route that row to manual
    review rather than guess at a split.
    """
    raw = (raw or "").strip()
    if not raw:
        return ParsedOwnerName(None, [], False)

    m = _ENTITY_PAREN_RE.match(raw)
    if m:
        entity = m.group("entity").strip().rstrip(",")
        owners, ok = _split_people(m.group("inside"))
        return ParsedOwnerName(entity, owners, ok)

    owners, ok = _split_people(raw)
    if ok:
        return ParsedOwnerName(None, owners, True)

    _, owners, ok = _split_lastname_comma(raw)
    if ok:
        return ParsedOwnerName(None, owners, True)

    return ParsedOwnerName(None, [], False)


# ---------------------------------------------------------------------------
# 4. Final CSV assembly — Contacts + Deals (two files, imported in order)
# ---------------------------------------------------------------------------

# contacts.contact_name (the primary field Airtable will match linked
# records against) is the formula: first_name & " " & last_name.
# It does NOT include llc_name. Every match string built anywhere in this
# pipeline must follow that exact shape, or the Deals CSV's links will
# silently fail to match on import.

CONTACT_COLUMNS = [
    "llc_name",
    "first_name",
    "last_name",
    "owner_role",
    "contact_type",
    "email",
    "phone",
    "is_acquisition",
]

DEAL_COLUMNS = [
    "deal_name",
    "main_category_acquisition_import",
    "sub_category_acquisition_import",
    "complex_acquisition_import",
    "unit_acquisition_import",
    "parcel_acquisition_import",
    "is_acquisition",
    "amount",
    "stage",
    "signed_rental_date",
    "owner_contact_acquisition_import",
    "sequence_order",
    "previous_deal_acquisition_import",
]


def contact_match_name(first_name: str, last_name: str) -> str:
    """The exact text contacts.contact_name will resolve to after import.

    Always first+last — never llc_name. Use this everywhere a match string
    is needed, rather than reconstructing the shape inline.
    """
    return f"{first_name or ''} {last_name or ''}".strip()


@dataclass
class UnitOwner:
    llc_name: str
    first_name: str
    last_name: str
    owner_role: str  # "Primary Owner" / "Secondary Owner"
    email: str
    phone: str
    completeness: str  # "Complete" / "Needs Manual Review"


def build_contacts_rows(unit_owner_map: dict[str, list[UnitOwner]]) -> list[dict]:
    """Dedupe owners across units into one row per unique contact.

    `unit_owner_map` maps a unit identifier to the list of UnitOwner for
    that unit. The same (llc_name, first_name, last_name) appearing under
    multiple units collapses to a single row here — that's the point: the
    Contacts table should never end up with duplicate people just because
    they own more than one unit.
    """
    seen: dict[tuple, dict] = {}
    for owners in unit_owner_map.values():
        for o in owners:
            # Dedupe on (first_name, last_name) only — contact_name (the
            # field Airtable links against) doesn't include llc_name, so two
            # rows with the same first+last but different llc_name would be
            # indistinguishable after import and are almost certainly the
            # same real person. Using llc_name in the key would silently
            # create duplicate Contacts for one person, which defeats the
            # whole point of deduping.
            key = (o.first_name, o.last_name)
            if key not in seen:
                seen[key] = {
                    "llc_name": o.llc_name,
                    "first_name": o.first_name,
                    "last_name": o.last_name,
                    "owner_role": o.owner_role,
                    "contact_type": "Current Liquid Life Owner",
                    "email": o.email,
                    "phone": o.phone,
                    "is_acquisition": "Yes, contact comes from an acquisition",
                }
            else:
                # Authority rule: a populated value beats a blank one.
                if not seen[key]["llc_name"] and o.llc_name:
                    seen[key]["llc_name"] = o.llc_name
                if not seen[key]["email"] and o.email:
                    seen[key]["email"] = o.email
                if not seen[key]["phone"] and o.phone:
                    seen[key]["phone"] = o.phone
    return list(seen.values())


def build_deal_row(
    unit_identifier: str,
    owners: list[UnitOwner],
    deal_amount,
    sub_category: str,
    signed_rental_date: Optional[str],
    parcel_identifier: str,
    complex_name: Optional[str] = None,
) -> dict:
    """Build one Deals-CSV row for a unit, linking to all of its owners.

    Note: `missing_parcel`/`missing_unit` are no longer accepted here — the
    downstream automations create missing Parcel/Unit/Complex records
    automatically regardless of any flag, so those columns were dropped
    from the export (2026-07). `sequence_order` and
    `previous_deal_acquisition_import` are NOT set here — call
    `assign_sequence_chain()` on the full list of rows after building them
    all, so the chain reflects final row order.
    """
    match_names = ", ".join(contact_match_name(o.first_name, o.last_name) for o in owners)
    return {
        "deal_name": f"Acquisition - {unit_identifier}",
        "main_category_acquisition_import": "Acquisition",
        "sub_category_acquisition_import": sub_category,
        "complex_acquisition_import": complex_name or "",
        "unit_acquisition_import": unit_identifier,
        "parcel_acquisition_import": parcel_identifier,
        "is_acquisition": "TRUE",
        "amount": deal_amount if deal_amount is not None else "",
        "stage": "Discovery/Qualification",
        "signed_rental_date": signed_rental_date or "",
        "owner_contact_acquisition_import": match_names,
        # sequence_order / previous_deal_acquisition_import filled in later
        # by assign_sequence_chain() — leave present but empty so DictWriter
        # doesn't choke on a missing key before that step runs.
        "sequence_order": "",
        "previous_deal_acquisition_import": "",
    }


def deal_row_completeness(owners: list[UnitOwner]) -> str:
    """Internal-only status, no longer exported as a CSV column (2026-07).

    Use this for the skill's own manual-review tracking/reporting in
    conversation (SKILL.md Step 5/7) — it does not get written to Airtable.
    """
    return (
        "Needs Manual Review"
        if any(o.completeness == "Needs Manual Review" for o in owners)
        else "Complete"
    )


def assign_sequence_chain(deal_rows: list[dict]) -> list[dict]:
    """Assign sequence_order + previous_deal_acquisition_import in place.

    Call this once, after all Deals-CSV rows have been built, right before
    writing the CSV. Row order in the input list becomes the chain order —
    row 0 is sequence_order=1 with no previous_deal, row 1 points back to
    row 0's deal_name, and so on. This chain is required for the
    categorization automations (sub_category/complex creation) to process
    more than the first deal in a batch — see target_schema.md
    "Sequencing".
    """
    previous_deal_name = ""
    for i, row in enumerate(deal_rows, start=1):
        row["sequence_order"] = i
        row["previous_deal_acquisition_import"] = previous_deal_name
        previous_deal_name = row["deal_name"]
    return deal_rows


def write_contacts_csv(rows: list[dict], out_path: str) -> None:
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CONTACT_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_deals_csv(rows: list[dict], out_path: str) -> None:
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=DEAL_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
